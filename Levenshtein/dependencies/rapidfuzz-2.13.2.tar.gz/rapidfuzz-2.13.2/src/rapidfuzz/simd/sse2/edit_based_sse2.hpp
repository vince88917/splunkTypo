#pragma once

#include "../../cpp_common.hpp"

namespace Sse2 {
#include "../edit_based_simd.incl"
}
