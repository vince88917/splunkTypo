#include "edit_based_sse2.hpp"

namespace Sse2 {
#include "../edit_based_simd.impl"
}
