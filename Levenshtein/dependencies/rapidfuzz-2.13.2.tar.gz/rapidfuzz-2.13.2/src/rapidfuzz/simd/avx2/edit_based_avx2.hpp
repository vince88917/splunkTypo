#pragma once

#include "cpp_common.hpp"

namespace Avx2 {
#include "../edit_based_simd.incl"
}
