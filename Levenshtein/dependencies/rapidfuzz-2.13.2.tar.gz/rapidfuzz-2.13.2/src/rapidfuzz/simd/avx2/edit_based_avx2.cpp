#include "edit_based_avx2.hpp"

namespace Avx2 {
#include "../edit_based_simd.impl"
}
