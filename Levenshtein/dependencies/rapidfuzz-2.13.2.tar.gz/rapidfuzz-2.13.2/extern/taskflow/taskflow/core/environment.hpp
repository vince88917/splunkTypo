#pragma once

#define TF_ENABLE_PROFILER "TF_ENABLE_PROFILER"

namespace tf {

}  // end of namespace tf -----------------------------------------------------

