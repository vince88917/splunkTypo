echo "To run a specific test:"
echo "  tox -e py27,py37 [test_file_path]::[test_name]"
